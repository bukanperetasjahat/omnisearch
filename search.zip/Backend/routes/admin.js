const express = require('express');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const { authorizeAdmin } = require('../middleware/authMiddleware');

const router = express.Router();

// Middleware to authorize only admin users
router.use(authorizeAdmin);

// Add new user
router.post('/add-user', async (req, res) => {
  try {
    const { username, password, role } = req.body;
    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }

    const existingUser = await User.findOne({ username });
    if (existingUser) return res.status(400).json({ message: 'Username already exists' });

    const passwordHash = await bcrypt.hash(password, 10);
    const newUser = new User({ username, passwordHash, role: role || 'user' });
    await newUser.save();

    res.status(201).json({ message: 'User added', userId: newUser._id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// Block or unblock a user
router.patch('/block-user/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { block } = req.body; // boolean

    const user = await User.findById(id);
    if (!user) return res.status(404).json({ message: 'User not found' });

    user.isBlocked = !!block;
    await user.save();

    res.json({ message: `User has been ${block ? 'blocked' : 'unblocked'}` });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// Add credits to a user
router.patch('/add-credits/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { credits } = req.body; // number

    if (typeof credits !== 'number' || credits <= 0) {
      return res.status(400).json({ message: 'Credits must be a positive number' });
    }

    const user = await User.findById(id);
    if (!user) return res.status(404).json({ message: 'User not found' });

    user.credits += credits;
    await user.save();

    res.json({ message: 'Credits added', credits: user.credits });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// Delete a user
router.delete('/delete-user/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const user = await User.findByIdAndDelete(id);

    if (!user) return res.status(404).json({ message: 'User not found' });

    res.json({ message: 'User deleted' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
