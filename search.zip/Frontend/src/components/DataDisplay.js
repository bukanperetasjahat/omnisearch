import React from 'react';

function DataDisplay() {
  return (
    <div>
      <h2>Data Display</h2>
      <p>View detailed data here.</p>
    </div>
  );
}

export default DataDisplay;
