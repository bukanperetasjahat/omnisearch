import React from 'react';

function UserDashboard() {
  return (
    <div>
      <h2>User Dashboard</h2>
      <p>Welcome to your user dashboard.</p>
    </div>
  );
}

export default UserDashboard;
