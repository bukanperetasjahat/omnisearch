import React from 'react';

function AdminDashboard() {
  return (
    <div>
      <h2>Admin Dashboard</h2>
      <p>Manage users and view admin-specific information here.</p>
    </div>
  );
}

export default AdminDashboard;
